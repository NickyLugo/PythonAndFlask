
#importación del framework
from flask import Flask, render_template, request, redirect, url_for, flash, session, after_this_request, jsonify
from flask_login import LoginManager, login_user, login_required, logout_user, current_user, UserMixin

#Se importa para desmenuzar la fecha 
from flask_mysqldb import MySQL

#Se importa para desmenuzar la fecha
from datetime import datetime
from flask_login import UserMixin
from flask_login import LoginManager
login_manager = LoginManager()

from flask import Flask
import pyodbc

#inicialización del APP (servidor)
app = Flask(__name__)
app.secret_key='mysecretkey'
#login_manager.init_app(app)


class User(UserMixin):
    def __init__(self, id, email, password, is_admin=False):
        self.id = id
        self.email = email
        self.password = password
        self.is_admin = is_admin
        # Other user attributes here

    def get_id(self):
        return str(self.id)

login_manager = LoginManager(app)
login_manager.login_view = 'iniciarMenuGenerico' #Publico
login_manager.login_message = 'Por favor, inicia sesión para acceder a esta página.' 

@login_manager.user_loader
def load_user(id):
    print("este es mi id: " + id)
    if int(id) == 1:
        print("Comprobación correcta")
        return User(id='1', email='121038198@upq.edu.mx', password='123')
    return None


try:
    app.config['SQL_SERVER_URI'] = 'DRIVER={SQL Server};SERVER=LAPTOP-H5L1Q96Q;DATABASE=db_unes_proyecto'
#UID=dba_NickLugo;PWD=123456
    # Test if the connection is successful
    connection = pyodbc.connect(app.config['SQL_SERVER_URI'])
    print("Conexión exitosa")
except Exception as ex:
    print(ex)



@app.route('/')
def iniciarMenuGenerico():
    return render_template('0-menu-generico.html')


@app.route('/login')
def iniciarLogin():
    return render_template('a-login-unes.html')


@app.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        if current_user.is_authenticated:
            return redirect(url_for('/pantalla-principal'))
        vEmail = request.form['txtEmail']
        vPassword = request.form['txtContrasena']

        user = User(id='1', email='121038198@upq.edu.mx', password='123')
        login_user(user)
        print("##HOLA## si entraste al LOGIN")
        if vEmail == '121038198@upq.edu.mx' and vPassword == '123':
            return redirect(url_for('iniciarMenu'))
        
            
        else:
            flash('Usuario o Contraseña Incorrectas')
            return render_template('a-login-unes.html')
    else:
        return render_template('a-login-unes.html')

@app.route('/menu')
def iniciarMenu():
    return render_template('menu.html')

@app.route('/registro-personas-unes')
@login_required
def iniciarRegistroPersonaUnes():
    return render_template('b-registro-persona.html')

@app.route('/botones-chofer-o-pasajero')
def iniciarChoferOPasajeroUnes():
    return render_template('c-botones-chofer-o-pasajero.html')

@app.route('/pantalla-principal')
def iniciarPantallaPrincipalUnes():
    return render_template('d-pantalla-principal.html')

@app.route('/buscar-viaje')
def iniciarBuscarViajeUnes():
    return render_template('e-buscar-viaje.html')

@app.route('/registro-vehiculo-unes')
def iniciarRegistroVehiculoUnes():
    return render_template('f-registro-vehiculo.html')

@app.route('/publicar-viaje')
def iniciarPublicarViajeUnes():
    return render_template('g-publicar-viaje.html')

@app.route('/mi-perfil')
def iniciarMiPerfil():
    return render_template('h-perfil-usuario.html')

#Método de trabajo POST que trabaja por detrás de lo que ve el usuario
@app.route('/registro-personas-unes', methods=['POST'])
def registrarPersona():
    if request.method == 'POST':

        #Pasamos a variables el contenido de los input, les ponemos una "v" de variable
        vNombrePersona = request.form["txtNombrePersona"]
        vApellidoPaternoPersona = request.form['txtApellidoPaterno']
        vApellidoMaternoPersona = request.form['txtApellidoMaterno']
        vFechaNacimiento = request.form['dateFechaNacimiento']
        vCarrera = request.form['txtCarrera']
        vEmail = request.form['txtEmail']
        vPassword = request.form['txtPassword']
        vTelefono = request.form['numberTelefono']   

        print("Los datos recogidos desde front son : {}, {}, {}, {}, {}, {}, {}".format(vNombrePersona, vApellidoPaternoPersona, vApellidoMaternoPersona, vFechaNacimiento, vCarrera, vEmail, vPassword, vTelefono))
        
        vFechaNacimiento = request.form['dateFechaNacimiento']
        date_object = datetime.strptime(vFechaNacimiento, '%Y-%m-%d')
        vFechaNacimiento = date_object.strftime('%Y-%m-%d')

        print("Los datos recogidos MODIFICADOS son: {}, {}, {}, {}, {}, {}, {}, {}".format(vNombrePersona, vApellidoPaternoPersona, vApellidoMaternoPersona, vFechaNacimiento, vCarrera, vEmail, vPassword, vTelefono))
        
        #QUERY
        consulta =pyodbc.connect(app.config['SQL_SERVER_URI'])
        cursor = consulta.cursor()
        #cursor.execute('EXEC InsertarEnLogin;')
        cursor.execute('INSERT INTO tb_personas(nombre_Usuario, ape_Paterno, ape_Materno, fecha_Nacimiento, carrera, email, contrasena, telefono) VALUES (?,?,?,?,?,?,?,?)',(vNombrePersona, vApellidoPaternoPersona, vApellidoMaternoPersona, vFechaNacimiento, vCarrera, vEmail, vPassword, vTelefono))
        consulta.commit()
        consulta.close()        

    session.pop('_flashes', None)
    flash('El registro fue existoso.')
    #cs.close()
    #se ocupará para que una vez que guardemos nos regrese al formulario", registrarPaciente es el nombre del método
    """ return redirect(url_for('registrarPersona')) """
    return redirect(url_for('iniciarLoginUnes'))

@app.route('/pantalla-principal', methods=['POST'])
@login_required
def elegirDesdeMain():
    if request.method == 'POST':
        print("Si estoy loggeado")
    return redirect(url_for('iniciarLoginUnes'))

#Para cerrar session
@app.route('/logout')
@login_required
def logout():
    @after_this_request
    def add_no_cache(response):
        response.headers['Cache-Control'] = 'no-store'
        return response

    logout_user()
    return redirect(url_for('index'))



#Ejecución del servidor en el puerto 5000 
if __name__ =='__main__':
    app.run(port=5001)
    #app.run(port=5000, debug = True)